package com.tiger.assistant

sealed interface Command {
    data class OpenApp(val name: String) : Command
    data class Ask(val text: String) : Command
}

object CommandRouter {
    private val openRegex = Regex("^(افتح|شغل|شغّل|فتح)\\s+(.+)$")

    fun parse(raw: String): Command {
        val text = raw.trim()
        val m = openRegex.find(text)
        return if (m != null) Command.OpenApp(m.groupValues[2].trim())
        else Command.Ask(text)
    }
}
