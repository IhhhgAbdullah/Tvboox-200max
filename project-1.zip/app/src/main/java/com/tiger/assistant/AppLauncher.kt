package com.tiger.assistant

import android.content.Context
import android.content.Intent

class AppLauncher(private val ctx: Context) {

    // أسماء عربية شائعة -> جزء من الاسم الإنجليزي للتطبيق
    private val aliases = mapOf(
        "يوتيوب" to "youtube",
        "نتفلكس" to "netflix",
        "نتفليكس" to "netflix",
        "شاهد" to "shahid",
        "الإعدادات" to "settings",
        "الاعدادات" to "settings",
        "كروم" to "chrome",
        "سبوتيفاي" to "spotify",
        "ديزني" to "disney",
        "بلاي ستور" to "play store"
    )

    private fun norm(s: String) = s.lowercase().replace("ال", "").trim()

    /** يرجع true إذا وجد التطبيق وفتحه */
    fun open(spokenName: String): Boolean {
        val pm = ctx.packageManager
        val target = aliases[spokenName.trim()] ?: spokenName.trim().lowercase()

        val leanback = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val normal = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(leanback, 0) + pm.queryIntentActivities(normal, 0)

        val match = apps.firstOrNull {
            it.loadLabel(pm).toString().lowercase().contains(target) ||
                norm(it.loadLabel(pm).toString()).contains(norm(target))
        } ?: return false

        val launch = pm.getLeanbackLaunchIntentForPackage(match.activityInfo.packageName)
            ?: pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return false

        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(launch)
        return true
    }
}
