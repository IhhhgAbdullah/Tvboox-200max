package com.tiger.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

private val NavyBg = Color(0xFF0B1B3A)
private val Gold = Color(0xFFD4AF37)

class MainActivity : ComponentActivity() {

    private lateinit var voice: VoiceController
    private lateinit var launcher: AppLauncher
    private val ai by lazy { AiClient(BuildConfig.AI_ENDPOINT) }

    private var status by mutableStateOf("اضغط الزر وتكلم")
    private var reply by mutableStateOf("")

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) voice.startListening() else status = "نحتاج صلاحية الميكروفون"
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        launcher = AppLauncher(this)
        voice = VoiceController(
            ctx = this,
            onListening = { status = "أستمع إليك..." },
            onResult = { handle(it) },
            onError = { status = it }
        )

        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Column(
                    modifier = Modifier.fillMaxSize().background(NavyBg).padding(48.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("مساعد تايغر", color = Gold, fontSize = 40.sp)
                    Spacer(Modifier.height(32.dp))
                    Button(
                        onClick = ::onMicClick,
                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = NavyBg)
                    ) { Text("🎤  تكلم", fontSize = 28.sp, modifier = Modifier.padding(12.dp)) }
                    Spacer(Modifier.height(24.dp))
                    Text(status, color = Color.White, fontSize = 22.sp)
                    Spacer(Modifier.height(16.dp))
                    Text(reply, color = Gold, fontSize = 26.sp)
                }
            }
        }
    }

    private fun onMicClick() {
        val ok = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (ok) voice.startListening() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun handle(text: String) {
        status = "سمعتك: $text"
        when (val cmd = CommandRouter.parse(text)) {
            is Command.OpenApp -> {
                val ok = launcher.open(cmd.name)
                reply = if (ok) "فتحت ${cmd.name}" else "ما لقيت تطبيق باسم ${cmd.name}"
                voice.speak(reply)
            }
            is Command.Ask -> lifecycleScope.launch {
                reply = "..."
                reply = try { ai.ask(cmd.text) } catch (e: Exception) { "تعذّر الاتصال: ${e.message}" }
                voice.speak(reply)
            }
        }
    }

    override fun onDestroy() {
        voice.release()
        super.onDestroy()
    }
}
