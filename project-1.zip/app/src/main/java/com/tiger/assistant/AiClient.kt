package com.tiger.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * يتصل بوسيط (Proxy) يحمل مفتاح الـ API ويمرر الطلب إلى Anthropic API.
 * الوسيط يستقبل {"messages": [...]} ويرجع رد Anthropic كما هو.
 */
class AiClient(private val endpoint: String) {

    private val http = OkHttpClient.Builder()
        .callTimeout(30, TimeUnit.SECONDS)
        .build()

    private val system = "أنت مساعد صوتي عربي على تلفزيون. أجب بجمل قصيرة وواضحة بالعربية، بدون تنسيق أو رموز."

    private val history = JSONArray()

    suspend fun ask(userText: String): String = withContext(Dispatchers.IO) {
        history.put(JSONObject().put("role", "user").put("content", userText))

        val body = JSONObject()
            .put("model", "claude-sonnet-5-5")
            .put("max_tokens", 300)
            .put("system", system)
            .put("messages", history)
            .toString()
            .toRequestBody("application/json".toMediaType())

        val req = Request.Builder().url(endpoint).post(body).build()
        http.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) error("خطأ من الخادم: ${resp.code}")
            val json = JSONObject(resp.body!!.string())
            val reply = json.getJSONArray("content").getJSONObject(0).getString("text")
            history.put(JSONObject().put("role", "assistant").put("content", reply))
            reply
        }
    }
}
